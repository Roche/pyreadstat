files into pandas data frames. It is a wrapper around the C library readstat.
Home-page: https://github.com/Roche/pyreadstat
Author: UNKNOWN
Author-email: UNKNOWN
License: UNKNOWN
Download-URL: https://github.com/Roche/pyreadstat/dist
Description-Content-Type: text/markdown
Description: Please visit out project home page for more information:<br>
        https://github.com/Roche/pyreadstat
Platform: UNKNOWN
Classifier: Programming Language :: Python
Classifier: Programming Language :: Cython
Classifier: Programming Language :: C
Classifier: License :: OSI Approved :: Apache Software License
Classifier: Intended Audience :: Science/Research
Classifier: Topic :: Scientific/Engineering
Classifier: Environment :: Console
